document.addEventListener("DOMContentLoaded", () => {
    // Select all Apply buttons inside job cards
    const applyButtons = document.querySelectorAll(".job-card button");

    applyButtons.forEach((button) => {
        button.addEventListener("click", () => {
            // Redirect to the Apply page
            window.location.href = "Apply.html"; // Adjust path if needed
        });
    });

    // Optional: Search functionality
    const searchBox = document.querySelector(".search-box");
    const searchButton = document.querySelector(".hero button");

    searchButton.addEventListener("click", () => {
        const query = searchBox.value.trim().toLowerCase();

        const jobs = document.querySelectorAll(".job-card");
        let found = false;

        jobs.forEach((job) => {
            const title = job.querySelector("h3").textContent.toLowerCase();
            const location = job.querySelector("p:nth-child(3)").textContent.toLowerCase();

            if (title.includes(query) || location.includes(query)) {
                job.style.display = "block";
                found = true;
            } else {
                job.style.display = "none";
            }
        });

        if (!found) {
            alert("No jobs found for: " + query);
        }
    });
});
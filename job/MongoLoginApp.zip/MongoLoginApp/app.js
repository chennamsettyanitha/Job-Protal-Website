// Load environment variables
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const path = require('path');
const cors = require('cors');
const bodyParser = require('body-parser');
const User = require('./models/User');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
const uri = process.env.MONGO_URI;
if (!uri) {
    console.error('MongoDB URI not defined. Check your .env file.');
    process.exit(1);
}

mongoose
    .connect(uri)
    .then(() => console.log('Connected to MongoDB'))
    .catch(err => {
        console.error('Error connecting to MongoDB:', err);
        process.exit(1);
    });

// Simulated session (for demonstration)
let loggedInUserId = null;

// Routes
app.get('/', (req, res) => {
    res.send('<h1>Welcome</h1><a href="/register.html">Register</a> | <a href="/login.html">Login</a>');
});

// Register
app.post('/register', async (req, res) => {
    const { username, email, password } = req.body;

    if (!username || !email || !password) {
        return res.status(400).send('All fields are required.');
    }

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send('Email already registered.');
        }

        const hashedPassword = await bcrypt.hash(password, 10);
        const newUser = new User({ username, email, password: hashedPassword });
        await newUser.save();

        res.send('Registration successful. Please <a href="/login.html">login</a>.');
    } catch (err) {
        console.error('Registration error:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Login
app.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).send('All fields are required.');
    }

    try {
        const user = await User.findOne({ email });
        if (!user || !(await bcrypt.compare(password, user.password))) {
            return res.status(401).send('Invalid email or password.');
        }

        loggedInUserId = user._id;
        res.json({ message: 'Login successful', userId: loggedInUserId });
    } catch (err) {
        console.error('Login error:', err);
        res.status(500).send('Internal Server Error');
    }
});

// Get Profile
app.get('/api/profile', async (req, res) => {
    if (!loggedInUserId) return res.status(401).json({ message: 'Not logged in' });

    try {
        const user = await User.findById(loggedInUserId).select('-password');
        if (!user) return res.status(404).json({ message: 'User not found' });

        res.json(user);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update Profile
app.put('/api/profile', async (req, res) => {
    if (!loggedInUserId) return res.status(401).json({ message: 'Not logged in' });

    const { username, email, location, about, skills, photo } = req.body;

    try {
        const updatedUser = await User.findByIdAndUpdate(
            loggedInUserId,
            {
                username,
                email,
                location,
                about,
                skills,
                photo
            },
            { new: true, runValidators: true }
        );

        if (!updatedUser) return res.status(404).json({ message: 'User not found' });

        res.json({ message: 'Profile updated successfully', user: updatedUser });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`✅ Server running at http://localhost:${PORT}`);
});
